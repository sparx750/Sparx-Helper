// Background script for Sparx Helper Chrome Extension

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        console.log('Sparx Helper installed');
        
        // Set default settings
        chrome.storage.sync.set({
            automaticMode: false,
            customTheme: false,
            selectedTheme: 'default',
            apiKey: ''
        });
    }
});

// Handle extension icon click
chrome.action.onClicked.addListener(async (tab) => {
    // This will open the popup, which is handled by the manifest
    // No additional action needed here since we have a popup defined
});

// Handle messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'updateBadge') {
        // Update extension badge based on helper status
        if (request.active) {
            chrome.action.setBadgeText({
                text: 'ON',
                tabId: sender.tab.id
            });
            chrome.action.setBadgeBackgroundColor({
                color: '#4CAF50',
                tabId: sender.tab.id
            });
        } else {
            chrome.action.setBadgeText({
                text: '',
                tabId: sender.tab.id
            });
        }
    }
    
    if (request.action === 'log') {
        console.log('Sparx Helper:', request.message);
    }
});

// Clean up badge when tab is closed or navigated away
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'loading' && tab.url) {
        if (!tab.url.includes('sparxmaths.uk') && !tab.url.includes('sparx.co.uk')) {
            chrome.action.setBadgeText({
                text: '',
                tabId: tabId
            });
        }
    }
});

chrome.tabs.onRemoved.addListener((tabId) => {
    // Badge automatically cleared when tab is closed
});