document.addEventListener('DOMContentLoaded', async () => {
    const activateBtn = document.getElementById('activateBtn');
    const deactivateBtn = document.getElementById('deactivateBtn');
    const statusText = document.getElementById('statusText');
    const automaticModeCheckbox = document.getElementById('automaticMode');
    const customThemeCheckbox = document.getElementById('customTheme');
    const themeOptions = document.getElementById('themeOptions');
    const apiKeyInput = document.getElementById('apiKey');
    const saveApiKeyBtn = document.getElementById('saveApiKey');

    // Load saved settings
    const settings = await chrome.storage.sync.get([
        'automaticMode', 
        'customTheme', 
        'selectedTheme', 
        'apiKey',
        'helperActive'
    ]);

    // Apply saved settings to UI
    if (settings.automaticMode) automaticModeCheckbox.checked = true;
    if (settings.customTheme) {
        customThemeCheckbox.checked = true;
        themeOptions.style.display = 'flex';
    }
    if (settings.selectedTheme) {
        const themeRadio = document.querySelector(`input[name="theme"][value="${settings.selectedTheme}"]`);
        if (themeRadio) themeRadio.checked = true;
    }
    if (settings.apiKey) {
        apiKeyInput.value = settings.apiKey;
    }

    // Check if helper is active
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && (tab.url.includes('sparxmaths.uk') || tab.url.includes('sparx.co.uk'))) {
            // Check if helper is already injected
            const results = await chrome.tabs.sendMessage(tab.id, { action: 'checkStatus' }).catch(() => null);
            if (results && results.active) {
                updateUIState(true);
            }
        } else {
            statusText.textContent = 'Please navigate to a Sparx page first';
            activateBtn.disabled = true;
        }
    } catch (error) {
        console.log('Tab check error:', error);
    }

    // Event listeners
    activateBtn.addEventListener('click', activateHelper);
    deactivateBtn.addEventListener('click', deactivateHelper);
    
    customThemeCheckbox.addEventListener('change', () => {
        themeOptions.style.display = customThemeCheckbox.checked ? 'flex' : 'none';
        saveSettings();
    });

    automaticModeCheckbox.addEventListener('change', saveSettings);

    document.querySelectorAll('input[name="theme"]').forEach(radio => {
        radio.addEventListener('change', saveSettings);
    });

    saveApiKeyBtn.addEventListener('click', async () => {
        const apiKey = apiKeyInput.value.trim();
        if (apiKey) {
            await chrome.storage.sync.set({ apiKey });
            statusText.textContent = 'API key saved successfully!';
            setTimeout(() => {
                statusText.textContent = 'Ready to help!';
            }, 2000);
        }
    });

    async function activateHelper() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            if (!tab || (!tab.url.includes('sparxmaths.uk') && !tab.url.includes('sparx.co.uk'))) {
                statusText.textContent = 'Please navigate to a Sparx page first';
                return;
            }

            statusText.textContent = 'Activating helper...';
            
            // Send message to content script to inject the helper
            await chrome.tabs.sendMessage(tab.id, { 
                action: 'activate',
                settings: {
                    automaticMode: automaticModeCheckbox.checked,
                    customTheme: customThemeCheckbox.checked,
                    selectedTheme: document.querySelector('input[name="theme"]:checked')?.value || 'default',
                    apiKey: apiKeyInput.value.trim()
                }
            });

            updateUIState(true);
            statusText.textContent = 'Helper activated successfully!';

        } catch (error) {
            console.error('Activation error:', error);
            statusText.textContent = 'Error: Make sure you\'re on a Sparx page and refresh if needed';
        }
    }

    async function deactivateHelper() {
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            await chrome.tabs.sendMessage(tab.id, { action: 'deactivate' });
            
            updateUIState(false);
            statusText.textContent = 'Helper deactivated';

        } catch (error) {
            console.error('Deactivation error:', error);
            statusText.textContent = 'Error deactivating helper';
        }
    }

    function updateUIState(active) {
        if (active) {
            activateBtn.style.display = 'none';
            deactivateBtn.style.display = 'block';
        } else {
            activateBtn.style.display = 'block';
            deactivateBtn.style.display = 'none';
        }
    }

    async function saveSettings() {
        const settings = {
            automaticMode: automaticModeCheckbox.checked,
            customTheme: customThemeCheckbox.checked,
            selectedTheme: document.querySelector('input[name="theme"]:checked')?.value || 'default'
        };

        await chrome.storage.sync.set(settings);

        // If helper is active, update its settings
        try {
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            await chrome.tabs.sendMessage(tab.id, { 
                action: 'updateSettings', 
                settings 
            }).catch(() => {}); // Ignore errors if helper not active
        } catch (error) {
            // Helper not active, that's fine
        }
    }
});